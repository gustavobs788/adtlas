import { type NextRequest, NextResponse } from "next/server"

interface AdContent {
  id: string
  title: string
  description: string
  cta: string
}

interface ClassificationResult {
  id: string
  funnelStage: "TOFU" | "MOFU" | "BOFU"
  confidence: number
  reasoning: string
}

export async function POST(request: NextRequest) {
  try {
    const { ads } = await request.json()

    if (!ads || !Array.isArray(ads)) {
      return NextResponse.json({ error: "Ads array is required" }, { status: 400 })
    }

    const classifications = await classifyAdsFunnel(ads)

    return NextResponse.json({
      classifications,
      total: classifications.length,
    })
  } catch (error) {
    console.error("Error classifying ads:", error)
    return NextResponse.json({ error: "Failed to classify ads" }, { status: 500 })
  }
}

async function classifyAdsFunnel(ads: AdContent[]): Promise<ClassificationResult[]> {
  const classifications: ClassificationResult[] = []

  for (const ad of ads) {
    try {
      const classification = fallbackClassification(ad)
      classifications.push(classification)
    } catch (error) {
      console.error(`Error classifying ad ${ad.id}:`, error)
      // Fallback to rule-based classification
      classifications.push(fallbackClassification(ad))
    }
  }

  return classifications
}

function fallbackClassification(ad: AdContent): ClassificationResult {
  const content = `${ad.title} ${ad.description} ${ad.cta}`.toLowerCase()

  // BOFU indicators (highest priority)
  const bofuKeywords = [
    "comprar",
    "compre",
    "desconto",
    "promoção",
    "oferta",
    "agora",
    "limitado",
    "últimos dias",
    "aproveite",
    "garanta",
    "adquira",
    "50%",
    "30%",
    "black friday",
    "cyber monday",
    "última chance",
    "por tempo limitado",
    "só hoje",
    "imperdível",
  ]

  // MOFU indicators
  const mofuKeywords = [
    "consulta",
    "consultoria",
    "demo",
    "demonstração",
    "teste",
    "grátis",
    "gratuito",
    "contato",
    "agendar",
    "solicitar",
    "orçamento",
    "proposta",
    "avaliação",
    "análise",
    "experimente",
    "trial",
    "cadastre-se",
    "inscreva-se",
    "baixe",
  ]

  // TOFU indicators
  const tofuKeywords = [
    "aprenda",
    "descubra",
    "saiba",
    "entenda",
    "guia",
    "dicas",
    "como fazer",
    "tutorial",
    "curso",
    "ebook",
    "webinar",
    "artigo",
    "blog",
    "informações",
    "transforme",
    "revolucione",
    "melhore",
    "otimize",
  ]

  let bofuScore = 0
  let mofuScore = 0
  let tofuScore = 0

  // Count keyword matches
  bofuKeywords.forEach((keyword) => {
    if (content.includes(keyword)) bofuScore++
  })

  mofuKeywords.forEach((keyword) => {
    if (content.includes(keyword)) mofuScore++
  })

  tofuKeywords.forEach((keyword) => {
    if (content.includes(keyword)) tofuScore++
  })

  // Determine stage based on highest score
  let stage: "TOFU" | "MOFU" | "BOFU" = "TOFU"
  let confidence = 0.6
  let reasoning = "Classificação baseada em análise de palavras-chave"

  if (bofuScore > mofuScore && bofuScore > tofuScore) {
    stage = "BOFU"
    confidence = Math.min(0.9, 0.6 + bofuScore * 0.1)
    reasoning = `Identificados ${bofuScore} indicadores de conversão/venda`
  } else if (mofuScore > tofuScore) {
    stage = "MOFU"
    confidence = Math.min(0.8, 0.6 + mofuScore * 0.1)
    reasoning = `Identificados ${mofuScore} indicadores de consideração/lead`
  } else if (tofuScore > 0) {
    stage = "TOFU"
    confidence = Math.min(0.8, 0.6 + tofuScore * 0.1)
    reasoning = `Identificados ${tofuScore} indicadores de conscientização/educação`
  }

  return {
    id: ad.id,
    funnelStage: stage,
    confidence,
    reasoning,
  }
}
