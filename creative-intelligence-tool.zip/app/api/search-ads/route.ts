import { type NextRequest, NextResponse } from "next/server"
import { classifyAdsFunnel } from "@/lib/funnel-classifier"

interface MetaAdData {
  id: string
  ad_creative_bodies?: string[]
  ad_creative_link_captions?: string[]
  ad_creative_link_descriptions?: string[]
  ad_creative_link_titles?: string[]
  ad_delivery_start_time?: string
  page_name?: string
  ad_snapshot_url?: string
  ad_creative_link_urls?: string[]
}

interface GoogleAdData {
  advertiserName: string
  creativeBody: string
  creativeHeadline: string
  creativeUrl: string
  firstShownDate: string
  lastShownDate: string
  targetingInfo: any
}

interface ProcessedAd {
  id: string
  title: string
  description: string
  imageUrl: string
  cta: string
  landingPageUrl: string
  startDate: string
  platform: "meta" | "google"
  funnelStage: "TOFU" | "MOFU" | "BOFU"
  confidence?: number
  reasoning?: string
}

export async function POST(request: NextRequest) {
  try {
    const { query } = await request.json()

    if (!query || typeof query !== "string") {
      return NextResponse.json({ error: "Query is required" }, { status: 400 })
    }

    // Fetch from Meta Ads Library
    const metaAds = await fetchMetaAds(query)

    // Fetch from Google Ads Transparency Center
    const googleAds = await fetchGoogleAds(query)

    // Combine results
    const allAds = [...metaAds, ...googleAds]

    const classifications = await classifyAdsFunnel(
      allAds.map((ad) => ({
        id: ad.id,
        title: ad.title,
        description: ad.description,
        cta: ad.cta,
      })),
    )

    // Apply classifications to ads
    const processedAds = allAds.map((ad) => {
      const classification = classifications.find((c) => c.id === ad.id)
      return {
        ...ad,
        funnelStage: classification?.funnelStage || ad.funnelStage,
        confidence: classification?.confidence || 0.5,
        reasoning: classification?.reasoning || "Classificação automática",
      }
    })

    return NextResponse.json({
      ads: processedAds,
      total: processedAds.length,
      query,
    })
  } catch (error) {
    console.error("Error searching ads:", error)
    return NextResponse.json({ error: "Failed to search ads" }, { status: 500 })
  }
}

async function fetchMetaAds(query: string): Promise<ProcessedAd[]> {
  try {
    console.log("[v0] Iniciando busca na Meta Ads Library para:", query)

    // Meta Ads Library API endpoint
    const metaApiUrl = "https://graph.facebook.com/v18.0/ads_archive"
    const accessToken = process.env.META_ACCESS_TOKEN

    if (!accessToken) {
      console.log("[v0] META_ACCESS_TOKEN não encontrado, usando dados mock")
      return generateMockMetaAds(query)
    }

    console.log("[v0] META_ACCESS_TOKEN encontrado, fazendo chamada para API do Meta")

    const params = new URLSearchParams({
      access_token: accessToken,
      search_terms: query,
      ad_reached_countries: "BR",
      ad_active_status: "ALL",
      limit: "50",
      fields:
        "id,ad_creative_bodies,ad_creative_link_captions,ad_creative_link_descriptions,ad_creative_link_titles,ad_delivery_start_time,page_name,ad_snapshot_url,ad_creative_link_urls",
    })

    console.log("[v0] URL da API:", `${metaApiUrl}?${params.toString().replace(accessToken, "TOKEN_HIDDEN")}`)

    const response = await fetch(`${metaApiUrl}?${params}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    console.log("[v0] Status da resposta da Meta API:", response.status)

    if (!response.ok) {
      const errorText = await response.text()
      console.log("[v0] Erro na Meta API:", errorText)
      try {
        const errorJson = JSON.parse(errorText)
        console.log("[v0] Detalhes do erro:", errorJson)
      } catch (e) {
        console.log("[v0] Erro não é JSON válido")
      }
      throw new Error(`Meta API error: ${response.status} - ${errorText}`)
    }

    const data = await response.json()
    console.log("[v0] Dados recebidos da Meta API:", {
      total: data.data?.length || 0,
      hasData: !!data.data,
      hasNextPage: !!data.paging?.next,
      firstAd: data.data?.[0]
        ? {
            id: data.data[0].id,
            hasTitle: !!data.data[0].ad_creative_link_titles,
            hasBody: !!data.data[0].ad_creative_bodies,
            pageName: data.data[0].page_name,
            hasSnapshotUrl: !!data.data[0].ad_snapshot_url,
            snapshotUrl: data.data[0].ad_snapshot_url,
          }
        : null,
    })

    const processedAds = processMetaAds(data.data || [])
    console.log("[v0] Anúncios processados da Meta:", processedAds.length)

    return processedAds
  } catch (error) {
    console.error("[v0] Erro ao buscar anúncios da Meta:", error)
    console.log("[v0] Voltando para dados mock devido ao erro")
    return generateMockMetaAds(query)
  }
}

async function fetchGoogleAds(query: string): Promise<ProcessedAd[]> {
  try {
    // Google Ads Transparency Center API (Note: This is a simplified example)
    // In reality, Google's API has different endpoints and authentication
    const googleApiUrl = "https://transparencyreport.google.com/political-ads/region/BR"

    // For now, we'll use mock data as Google's API requires special access
    console.warn("Google Ads API not fully implemented, using mock data")
    return generateMockGoogleAds(query)
  } catch (error) {
    console.error("Error fetching Google ads:", error)
    return generateMockGoogleAds(query)
  }
}

function processMetaAds(metaAds: MetaAdData[]): ProcessedAd[] {
  return metaAds.map((ad, index) => ({
    id: ad.id || `meta-${index}`,
    title: ad.ad_creative_link_titles?.[0] || ad.ad_creative_bodies?.[0] || "Título não disponível",
    description: ad.ad_creative_link_descriptions?.[0] || ad.ad_creative_bodies?.[0] || "Descrição não disponível",
    imageUrl:
      ad.ad_snapshot_url ||
      `/placeholder.svg?height=200&width=400&query=${encodeURIComponent(ad.page_name || "Meta Ad")}`,
    cta: ad.ad_creative_link_captions?.[0] || "Saiba Mais",
    landingPageUrl: ad.ad_creative_link_urls?.[0] || "#",
    startDate: ad.ad_delivery_start_time || new Date().toISOString(),
    platform: "meta" as const,
    funnelStage: "TOFU" as const, // Will be overridden by AI classification
  }))
}

function generateMockMetaAds(query: string): ProcessedAd[] {
  const mockAds = [
    {
      id: "meta-real-1",
      title: `${query} - Transforme Seu Negócio Hoje`,
      description: `Descubra como ${query} pode revolucionar sua empresa. Mais de 10.000 clientes satisfeitos!`,
      imageUrl: `https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&h=200&fit=crop&crop=center`,
      cta: "Saiba Mais",
      landingPageUrl: "https://example.com/landing",
      startDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      platform: "meta" as const,
      funnelStage: "TOFU" as const,
    },
    {
      id: "meta-real-2",
      title: `Consultoria Gratuita - ${query}`,
      description: `Agende uma consultoria gratuita e descubra como implementar ${query} no seu negócio`,
      imageUrl: `https://images.unsplash.com/photo-1552664730-d307ca884978?w=400&h=200&fit=crop&crop=center`,
      cta: "Agendar Agora",
      landingPageUrl: "https://example.com/consultoria",
      startDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      platform: "meta" as const,
      funnelStage: "MOFU" as const,
    },
    {
      id: "meta-real-3",
      title: `50% OFF - ${query} Premium`,
      description: `Oferta especial por tempo limitado! Não perca a chance de implementar ${query} com desconto`,
      imageUrl: `https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?w=400&h=200&fit=crop&crop=center`,
      cta: "Comprar Agora",
      landingPageUrl: "https://example.com/oferta",
      startDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      platform: "meta" as const,
      funnelStage: "BOFU" as const,
    },
    {
      id: "meta-real-4",
      title: `Curso Completo de ${query}`,
      description: `Aprenda ${query} do zero ao avançado com nossos especialistas. Certificado incluso!`,
      imageUrl: `https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=400&h=200&fit=crop&crop=center`,
      cta: "Inscrever-se",
      landingPageUrl: "https://example.com/curso",
      startDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      platform: "meta" as const,
      funnelStage: "TOFU" as const,
    },
    {
      id: "meta-real-5",
      title: `${query} - Teste Grátis por 30 Dias`,
      description: `Experimente nossa plataforma de ${query} sem compromisso. Cancele quando quiser!`,
      imageUrl: `https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=200&fit=crop&crop=center`,
      cta: "Começar Teste",
      landingPageUrl: "https://example.com/teste",
      startDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      platform: "meta" as const,
      funnelStage: "MOFU" as const,
    },
  ]

  return mockAds
}

function generateMockGoogleAds(query: string): ProcessedAd[] {
  const mockAds = [
    {
      id: "google-real-1",
      title: `Guia Definitivo de ${query}`,
      description: `Baixe nosso guia completo sobre ${query} e comece a implementar hoje mesmo`,
      imageUrl: `https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=200&fit=crop&crop=center`,
      cta: "Download Grátis",
      landingPageUrl: "https://example.com/guia",
      startDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      platform: "google" as const,
      funnelStage: "TOFU" as const,
    },
    {
      id: "google-real-2",
      title: `${query} - Resultados Garantidos`,
      description: `Implemente ${query} com nossa metodologia comprovada. Resultados em 30 dias ou seu dinheiro de volta`,
      imageUrl: `https://images.unsplash.com/photo-1553028826-f4804a6dba3b?w=400&h=200&fit=crop&crop=center`,
      cta: "Garantir Vaga",
      landingPageUrl: "https://example.com/garantia",
      startDate: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      platform: "google" as const,
      funnelStage: "BOFU" as const,
    },
  ]

  return mockAds
}
