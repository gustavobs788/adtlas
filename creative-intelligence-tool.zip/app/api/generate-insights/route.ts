import { type NextRequest, NextResponse } from "next/server"

interface AdData {
  id: string
  title: string
  description: string
  cta: string
  platform: "meta" | "google"
  funnelStage: "TOFU" | "MOFU" | "BOFU"
}

interface InsightsResponse {
  commonTriggers: string[]
  creativesSuggestions: {
    tofu: string
    mofu: string
    bofu: string
  }
  landingPageStructure: string[]
  competitiveAnalysis: {
    strengths: string[]
    opportunities: string[]
    trends: string[]
  }
  recommendations: {
    immediate: string[]
    longTerm: string[]
  }
}

export async function POST(request: NextRequest) {
  try {
    const { ads, query } = await request.json()

    if (!ads || !Array.isArray(ads)) {
      return NextResponse.json({ error: "Ads array is required" }, { status: 400 })
    }

    const insights = await generateInsights(ads, query || "")

    return NextResponse.json(insights)
  } catch (error) {
    console.error("Error generating insights:", error)
    return NextResponse.json({ error: "Failed to generate insights" }, { status: 500 })
  }
}

async function generateInsights(ads: AdData[], query: string): Promise<InsightsResponse> {
  try {
    const triggers = extractTriggersFromContent(ads)
    const creatives = generateCreativeSuggestions(ads, query)
    const landingPage = generateLandingPageStructure(ads, query)
    const competitive = analyzeCompetitiveLandscape(ads, query)
    const recommendations = generateRecommendations(ads, query)

    return {
      commonTriggers: triggers,
      creativesSuggestions: creatives,
      landingPageStructure: landingPage,
      competitiveAnalysis: competitive,
      recommendations,
    }
  } catch (error) {
    console.error("Error in insights generation:", error)
    return generateFallbackInsights(ads, query)
  }
}

function extractTriggersFromContent(ads: AdData[]): string[] {
  const allContent = ads
    .map((ad) => `${ad.title} ${ad.description} ${ad.cta}`)
    .join(" ")
    .toLowerCase()

  const triggerKeywords = {
    Urgência: ["agora", "hoje", "rápido", "imediato", "últimos dias", "por tempo limitado"],
    Escassez: ["limitado", "exclusivo", "poucos", "restante", "última chance", "só hoje"],
    Desconto: ["desconto", "promoção", "oferta", "%", "grátis", "50%", "30%"],
    Autoridade: ["especialista", "profissional", "certificado", "anos de experiência", "líder"],
    "Prova Social": ["clientes", "empresas", "satisfeitos", "resultados", "casos", "depoimentos"],
    Transformação: ["transforme", "mude", "revolucione", "melhore", "aumente", "otimize"],
    Benefício: ["economize", "ganhe", "conquiste", "alcance", "realize", "obtenha"],
    Facilidade: ["fácil", "simples", "rápido", "sem complicação", "prático", "intuitivo"],
  }

  const foundTriggers: string[] = []

  Object.entries(triggerKeywords).forEach(([trigger, keywords]) => {
    if (keywords.some((keyword) => allContent.includes(keyword))) {
      foundTriggers.push(trigger)
    }
  })

  return foundTriggers.length > 0 ? foundTriggers : ["Urgência", "Desconto", "Transformação", "Prova Social"]
}

function generateCreativeSuggestions(
  ads: AdData[],
  query: string,
): {
  tofu: string
  mofu: string
  bofu: string
} {
  const tofuAds = ads.filter((ad) => ad.funnelStage === "TOFU")
  const mofuAds = ads.filter((ad) => ad.funnelStage === "MOFU")
  const bofuAds = ads.filter((ad) => ad.funnelStage === "BOFU")

  // Análise dos padrões encontrados
  const hasEducationalContent = tofuAds.some(
    (ad) =>
      ad.title.toLowerCase().includes("aprenda") ||
      ad.title.toLowerCase().includes("descubra") ||
      ad.title.toLowerCase().includes("guia"),
  )

  const hasLeadMagnets = mofuAds.some(
    (ad) =>
      ad.title.toLowerCase().includes("grátis") ||
      ad.title.toLowerCase().includes("consulta") ||
      ad.title.toLowerCase().includes("demo"),
  )

  const hasUrgency = bofuAds.some(
    (ad) =>
      ad.title.toLowerCase().includes("desconto") ||
      ad.title.toLowerCase().includes("oferta") ||
      ad.title.toLowerCase().includes("limitado"),
  )

  return {
    tofu: hasEducationalContent
      ? `Crie conteúdo educativo sobre ${query} seguindo o padrão dos concorrentes: guias práticos, tutoriais e dicas que resolvam problemas reais do seu público-alvo`
      : `Desenvolva conteúdo de conscientização sobre ${query}, focando em educar o mercado sobre os benefícios e aplicações práticas`,

    mofu: hasLeadMagnets
      ? `Ofereça lead magnets como os concorrentes: consultorias gratuitas, demos personalizadas ou análises sobre ${query} para capturar leads qualificados`
      : `Crie ofertas de consideração para ${query}: trials gratuitos, webinars exclusivos ou materiais aprofundados para nutrir prospects`,

    bofu: hasUrgency
      ? `Use gatilhos de urgência e escassez como os concorrentes: ofertas por tempo limitado, descontos exclusivos e CTAs que aceleram a decisão de compra de ${query}`
      : `Implemente estratégias de conversão para ${query}: garantias, depoimentos de clientes e ofertas irresistíveis que removam objeções`,
  }
}

function generateLandingPageStructure(ads: AdData[], query: string): string[] {
  const commonElements = [
    "Headline impactante com benefício principal",
    "Subheadline explicando a proposta de valor",
    "Vídeo explicativo ou imagem hero de alta qualidade",
    "Seção de benefícios principais com ícones",
    "Depoimentos e casos de sucesso reais",
    "CTA principal bem destacado e visível",
    "Seção de recursos/funcionalidades",
    "FAQ para responder objeções comuns",
    "Garantia ou política de devolução",
    "Formulário de contato otimizado",
  ]

  // Personalizar baseado nos anúncios analisados
  const hasTestimonials = ads.some(
    (ad) => ad.description.toLowerCase().includes("cliente") || ad.description.toLowerCase().includes("resultado"),
  )

  const hasDemo = ads.some((ad) => ad.cta.toLowerCase().includes("demo") || ad.cta.toLowerCase().includes("teste"))

  if (hasTestimonials) {
    commonElements.splice(
      4,
      1,
      "Seção robusta de depoimentos e casos de sucesso (padrão identificado nos concorrentes)",
    )
  }

  if (hasDemo) {
    commonElements.splice(5, 1, "CTA para demonstração/teste gratuito (estratégia comum dos concorrentes)")
  }

  return commonElements.slice(0, 8) // Retorna os 8 elementos mais importantes
}

function analyzeCompetitiveLandscape(
  ads: AdData[],
  query: string,
): {
  strengths: string[]
  opportunities: string[]
  trends: string[]
} {
  const metaAds = ads.filter((ad) => ad.platform === "meta")
  const googleAds = ads.filter((ad) => ad.platform === "google")

  const tofuCount = ads.filter((ad) => ad.funnelStage === "TOFU").length
  const mofuCount = ads.filter((ad) => ad.funnelStage === "MOFU").length
  const bofuCount = ads.filter((ad) => ad.funnelStage === "BOFU").length

  const strengths = [
    "Uso efetivo de prova social nos anúncios analisados",
    "CTAs claros e diretos em todas as campanhas",
    "Segmentação por funil bem estruturada",
  ]

  const opportunities = [
    "Explorar canais menos saturados que os concorrentes",
    "Personalização mais avançada baseada no comportamento",
    "Foco em benefícios únicos não explorados",
  ]

  const trends = ["Crescimento do marketing de conteúdo educativo", "Automação de campanhas por estágio de funil"]

  // Análise baseada na distribuição dos anúncios
  if (tofuCount > mofuCount + bofuCount) {
    trends.push("Foco em conscientização e educação do mercado")
  } else if (bofuCount > tofuCount + mofuCount) {
    trends.push("Estratégias agressivas de conversão direta")
  } else {
    trends.push("Abordagem equilibrada em todo o funil de vendas")
  }

  if (metaAds.length > googleAds.length * 2) {
    strengths.push("Forte presença no Meta/Facebook")
    opportunities.push("Expandir investimento no Google Ads")
  } else if (googleAds.length > metaAds.length * 2) {
    strengths.push("Domínio das campanhas de busca no Google")
    opportunities.push("Aumentar presença nas redes sociais")
  }

  return { strengths, opportunities, trends }
}

function generateRecommendations(
  ads: AdData[],
  query: string,
): {
  immediate: string[]
  longTerm: string[]
} {
  const totalAds = ads.length
  const tofuPercentage = (ads.filter((ad) => ad.funnelStage === "TOFU").length / totalAds) * 100
  const bofuPercentage = (ads.filter((ad) => ad.funnelStage === "BOFU").length / totalAds) * 100

  const immediate = [
    "Teste A/B com diferentes headlines baseadas nos padrões identificados",
    "Implemente CTAs mais específicos por estágio de funil",
    "Crie landing pages otimizadas para cada campanha",
  ]

  const longTerm = [
    "Desenvolva uma estratégia de conteúdo para nutrir leads",
    "Implemente automação de marketing por estágio de funil",
    "Expanda presença em canais menos explorados pelos concorrentes",
  ]

  // Recomendações baseadas na análise
  if (tofuPercentage > 60) {
    immediate.push("Equilibre o funil criando mais campanhas MOFU e BOFU")
  } else if (bofuPercentage > 50) {
    immediate.push("Invista em campanhas TOFU para ampliar o topo do funil")
  }

  if (ads.filter((ad) => ad.platform === "meta").length === 0) {
    longTerm.push("Considere expandir para campanhas no Meta/Facebook")
  }

  if (ads.filter((ad) => ad.platform === "google").length === 0) {
    longTerm.push("Avalie oportunidades no Google Ads para capturar intenção de busca")
  }

  return { immediate: immediate.slice(0, 4), longTerm: longTerm.slice(0, 4) }
}

function generateFallbackInsights(ads: AdData[], query: string): InsightsResponse {
  return {
    commonTriggers: extractTriggersFromContent(ads),
    creativesSuggestions: {
      tofu: `Crie conteúdo educativo sobre ${query}, focando em resolver problemas comuns do seu público-alvo`,
      mofu: `Ofereça demonstrações gratuitas ou consultorias sobre ${query} para capturar leads qualificados`,
      bofu: `Use urgência e ofertas limitadas para acelerar a decisão de compra de ${query}`,
    },
    landingPageStructure: [
      "Headline impactante com benefício principal",
      "Vídeo explicativo ou imagem hero",
      "Seção de benefícios com ícones",
      "Depoimentos e casos de sucesso",
      "CTA principal bem destacado",
      "FAQ para objeções comuns",
      "Garantia ou política de devolução",
    ],
    competitiveAnalysis: {
      strengths: ["Uso efetivo de prova social", "CTAs claros e diretos", "Segmentação por funil bem definida"],
      opportunities: [
        "Explorar novos canais de comunicação",
        "Personalização mais avançada",
        "Foco em benefícios únicos",
      ],
      trends: ["Crescimento do marketing de conteúdo", "Automação de campanhas", "Foco em experiência do usuário"],
    },
    recommendations: {
      immediate: [
        "Teste A/B com diferentes headlines baseadas nos padrões identificados",
        "Implemente CTAs mais específicos por estágio de funil",
        "Crie landing pages otimizadas para cada campanha",
      ],
      longTerm: [
        "Desenvolva uma estratégia de conteúdo para nutrir leads",
        "Implemente automação de marketing por estágio de funil",
        "Expanda presença em canais menos explorados pelos concorrentes",
      ],
    },
  }
}
