"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { SearchResults } from "@/components/search-results"
import { searchAds, generateInsights } from "@/lib/api-client"
import { useToast } from "@/hooks/use-toast"

const SearchIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="m21 21-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
  </svg>
)

const SparklesIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M5 3l1.5 1.5L5 6l-1.5-1.5L5 3zM19 3l1.5 1.5L19 6l-1.5-1.5L19 3zM12 8l1.5 1.5L12 11l-1.5-1.5L12 8zM5 21l1.5-1.5L5 18l-1.5 1.5L5 21zM19 21l1.5-1.5L19 18l-1.5 1.5L19 21z"
    />
  </svg>
)

const TargetIcon = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="10" strokeWidth={2} />
    <circle cx="12" cy="12" r="6" strokeWidth={2} />
    <circle cx="12" cy="12" r="2" strokeWidth={2} />
  </svg>
)

const TrendingUpIcon = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <polyline points="22,7 13.5,15.5 8.5,10.5 2,17" strokeWidth={2} />
    <polyline points="16,7 22,7 22,13" strokeWidth={2} />
  </svg>
)

export default function HomePage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [isSearching, setIsSearching] = useState(false)
  const [searchResults, setSearchResults] = useState<{
    query: string
    ads: any[]
    insights: any
  } | null>(null)
  const { toast } = useToast()

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!searchQuery.trim()) return

    setIsSearching(true)

    try {
      const adsResponse = await searchAds(searchQuery.trim())
      const insights = await generateInsights(adsResponse.ads, searchQuery.trim())

      setSearchResults({
        query: searchQuery,
        ads: adsResponse.ads,
        insights,
      })
    } catch (error) {
      console.error("Search error:", error)
      toast({
        title: "Erro na busca",
        description: "Não foi possível buscar os anúncios. Tente novamente.",
        variant: "destructive",
      })
    } finally {
      setIsSearching(false)
    }
  }

  const handleNewSearch = () => {
    setSearchResults(null)
    setSearchQuery("")
  }

  if (searchResults) {
    return (
      <div className="min-h-screen">
        {/* Header */}
        <header className="border-b border-border/50 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <button onClick={handleNewSearch} className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                  <SparklesIcon />
                </div>
                <h1 className="text-xl font-bold text-foreground">AdIntel</h1>
              </button>
              <div className="flex items-center gap-4">
                <form onSubmit={handleSearch} className="flex gap-2">
                  <Input
                    type="text"
                    placeholder="Nova busca..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-64 bg-card/50 border-border/50"
                  />
                  <Button type="submit" size="sm" disabled={isSearching || !searchQuery.trim()}>
                    <SearchIcon />
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </header>

        <SearchResults {...searchResults} />
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="border-b border-border/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
                <SparklesIcon />
              </div>
              <h1 className="text-xl font-bold text-foreground">AdIntel</h1>
            </div>
            <nav className="hidden md:flex items-center gap-6">
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                Recursos
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                Preços
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
                Contato
              </a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <div className="mb-8">
            <h2 className="text-4xl md:text-6xl font-bold text-balance mb-6">
              Descubra os <span className="text-primary">segredos</span> dos anúncios
              <br />
              que convertem
            </h2>
            <p className="text-xl text-muted-foreground text-balance max-w-2xl mx-auto">
              Analise anúncios de concorrentes, organize por funil de vendas e receba insights automáticos para criar
              campanhas mais eficazes.
            </p>
          </div>

          {/* Search Form */}
          <form onSubmit={handleSearch} className="mb-12">
            <div className="flex flex-col sm:flex-row gap-4 max-w-2xl mx-auto">
              <div className="relative flex-1">
                <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground">
                  <SearchIcon />
                </div>
                <Input
                  type="text"
                  placeholder="Digite o nome do concorrente ou setor"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 h-12 text-lg bg-card/50 border-border/50 backdrop-blur-sm"
                />
              </div>
              <Button type="submit" size="lg" disabled={isSearching || !searchQuery.trim()} className="h-12 px-8">
                {isSearching ? (
                  <>
                    <div className="w-4 h-4 border-2 border-primary-foreground/30 border-t-primary-foreground rounded-full animate-spin mr-2" />
                    Analisando...
                  </>
                ) : (
                  <>
                    <SearchIcon />
                    <span className="ml-2">Analisar Anúncios</span>
                  </>
                )}
              </Button>
            </div>
          </form>

          {/* Features Grid */}
          <div className="grid md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            <Card className="card-gradient border-border/50">
              <CardHeader className="text-center">
                <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center mx-auto mb-4">
                  <TargetIcon />
                </div>
                <CardTitle className="text-xl">Organização por Funil</CardTitle>
                <CardDescription>Anúncios classificados automaticamente em TOFU, MOFU e BOFU</CardDescription>
              </CardHeader>
            </Card>

            <Card className="card-gradient border-border/50">
              <CardHeader className="text-center">
                <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center mx-auto mb-4">
                  <SparklesIcon />
                </div>
                <CardTitle className="text-xl">Insights com IA</CardTitle>
                <CardDescription>Análise automática de gatilhos, padrões e sugestões de criativos</CardDescription>
              </CardHeader>
            </Card>

            <Card className="card-gradient border-border/50">
              <CardHeader className="text-center">
                <div className="w-12 h-12 rounded-lg bg-chart-2/20 flex items-center justify-center mx-auto mb-4">
                  <TrendingUpIcon />
                </div>
                <CardTitle className="text-xl">Múltiplas Fontes</CardTitle>
                <CardDescription>Dados do Meta Ads Library e Google Ads Transparency Center</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
