interface AdContent {
  id: string
  title: string
  description: string
  cta: string
}

interface ClassificationResult {
  id: string
  funnelStage: "TOFU" | "MOFU" | "BOFU"
  confidence: number
  reasoning: string
}

export async function classifyAdsFunnel(ads: AdContent[]): Promise<ClassificationResult[]> {
  try {
    const response = await fetch("/api/classify-funnel", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ ads }),
    })

    if (!response.ok) {
      throw new Error(`Classification failed: ${response.statusText}`)
    }

    const data = await response.json()
    return data.classifications
  } catch (error) {
    console.error("Error classifying ads:", error)
    // Fallback to client-side classification
    return ads.map((ad) => fallbackClassifyAd(ad))
  }
}

function fallbackClassifyAd(ad: AdContent): ClassificationResult {
  const content = `${ad.title} ${ad.description} ${ad.cta}`.toLowerCase()

  // Simple rule-based classification as fallback
  if (
    content.includes("comprar") ||
    content.includes("desconto") ||
    content.includes("oferta") ||
    content.includes("agora")
  ) {
    return {
      id: ad.id,
      funnelStage: "BOFU",
      confidence: 0.7,
      reasoning: "Indicadores de conversão detectados",
    }
  }

  if (
    content.includes("consulta") ||
    content.includes("demo") ||
    content.includes("grátis") ||
    content.includes("contato")
  ) {
    return {
      id: ad.id,
      funnelStage: "MOFU",
      confidence: 0.7,
      reasoning: "Indicadores de consideração detectados",
    }
  }

  return {
    id: ad.id,
    funnelStage: "TOFU",
    confidence: 0.6,
    reasoning: "Classificação padrão para conscientização",
  }
}

export function getFunnelStageInfo(stage: "TOFU" | "MOFU" | "BOFU") {
  const stageInfo = {
    TOFU: {
      name: "Top of Funnel",
      description: "Conscientização e Educação",
      color: "bg-chart-1/20 text-chart-1 border-chart-1/30",
      objectives: ["Gerar awareness", "Educar o público", "Criar interesse"],
      metrics: ["Impressões", "Alcance", "Engajamento"],
    },
    MOFU: {
      name: "Middle of Funnel",
      description: "Consideração e Avaliação",
      color: "bg-chart-2/20 text-chart-2 border-chart-2/30",
      objectives: ["Gerar leads", "Nutrir interesse", "Demonstrar valor"],
      metrics: ["Leads gerados", "Taxa de conversão", "Custo por lead"],
    },
    BOFU: {
      name: "Bottom of Funnel",
      description: "Conversão e Venda",
      color: "bg-chart-3/20 text-chart-3 border-chart-3/30",
      objectives: ["Converter vendas", "Acelerar decisão", "Maximizar ROI"],
      metrics: ["Vendas", "ROI", "Custo por aquisição"],
    },
  }

  return stageInfo[stage]
}
