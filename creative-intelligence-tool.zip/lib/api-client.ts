interface SearchAdsResponse {
  ads: Array<{
    id: string
    title: string
    description: string
    imageUrl: string
    cta: string
    landingPageUrl: string
    startDate: string
    platform: "meta" | "google"
    funnelStage: "TOFU" | "MOFU" | "BOFU"
    confidence?: number
    reasoning?: string
  }>
  total: number
  query: string
}

interface InsightsResponse {
  commonTriggers: string[]
  creativesSuggestions: {
    tofu: string
    mofu: string
    bofu: string
  }
  landingPageStructure: string[]
  competitiveAnalysis: {
    strengths: string[]
    opportunities: string[]
    trends: string[]
  }
  recommendations: {
    immediate: string[]
    longTerm: string[]
  }
}

export async function searchAds(query: string): Promise<SearchAdsResponse> {
  const response = await fetch("/api/search-ads", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ query }),
  })

  if (!response.ok) {
    throw new Error(`Failed to search ads: ${response.statusText}`)
  }

  return response.json()
}

export async function generateInsights(ads: SearchAdsResponse["ads"], query?: string): Promise<InsightsResponse> {
  const response = await fetch("/api/generate-insights", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      ads: ads.map((ad) => ({
        id: ad.id,
        title: ad.title,
        description: ad.description,
        cta: ad.cta,
        platform: ad.platform,
        funnelStage: ad.funnelStage,
      })),
      query,
    }),
  })

  if (!response.ok) {
    throw new Error(`Failed to generate insights: ${response.statusText}`)
  }

  return response.json()
}
