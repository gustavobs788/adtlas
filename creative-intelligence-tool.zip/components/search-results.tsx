"use client"
import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { getFunnelStageInfo } from "@/lib/funnel-classifier"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

const ExternalLinkIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
    />
  </svg>
)

const EyeIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"
    />
  </svg>
)

const CalendarIcon = () => (
  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <rect x="3" y="4" width="18" height="18" rx="2" ry="2" strokeWidth={2} />
    <line x1="16" y1="2" x2="16" y2="6" strokeWidth={2} />
    <line x1="8" y1="2" x2="8" y2="6" strokeWidth={2} />
    <line x1="3" y1="10" x2="21" y2="10" strokeWidth={2} />
  </svg>
)

const TargetIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="10" strokeWidth={2} />
    <circle cx="12" cy="12" r="6" strokeWidth={2} />
    <circle cx="12" cy="12" r="2" strokeWidth={2} />
  </svg>
)

const InfoIcon = () => (
  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="10" strokeWidth={2} />
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 16v-4M12 8h.01" />
  </svg>
)

const TrendingUpIcon = () => (
  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <polyline points="22,7 13.5,15.5 8.5,10.5 2,17" strokeWidth={2} />
    <polyline points="16,7 22,7 22,13" strokeWidth={2} />
  </svg>
)

const LightbulbIcon = () => (
  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
    />
  </svg>
)

const CheckCircleIcon = () => (
  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth={2}
      d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
    />
  </svg>
)

interface AdData {
  id: string
  title: string
  description: string
  imageUrl: string
  cta: string
  landingPageUrl: string
  startDate: string
  platform: "meta" | "google"
  funnelStage: "TOFU" | "MOFU" | "BOFU"
  confidence?: number
  reasoning?: string
}

interface SearchResultsProps {
  query: string
  ads: AdData[]
  insights: {
    commonTriggers: string[]
    creativesSuggestions: {
      tofu: string
      mofu: string
      bofu: string
    }
    landingPageStructure: string[]
    competitiveAnalysis?: {
      strengths: string[]
      opportunities: string[]
      trends: string[]
    }
    recommendations?: {
      immediate: string[]
      longTerm: string[]
    }
  }
}

export function SearchResults({ query, ads, insights }: SearchResultsProps) {
  const [selectedStage, setSelectedStage] = useState<"all" | "TOFU" | "MOFU" | "BOFU">("all")

  const filteredAds = selectedStage === "all" ? ads : ads.filter((ad) => ad.funnelStage === selectedStage)

  const getStageColor = (stage: string) => {
    const stageInfo = getFunnelStageInfo(stage as "TOFU" | "MOFU" | "BOFU")
    return stageInfo?.color || "bg-muted/20 text-muted-foreground border-muted/30"
  }

  const getPlatformColor = (platform: string) => {
    return platform === "meta" ? "bg-blue-500/20 text-blue-400" : "bg-green-500/20 text-green-400"
  }

  return (
    <TooltipProvider>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Resultados para "{query}"</h2>
          <p className="text-muted-foreground">
            Encontrados {ads.length} anúncios organizados por estágio de funil com classificação IA
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Filter Tabs */}
            <Tabs value={selectedStage} onValueChange={(value) => setSelectedStage(value as any)} className="mb-6">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="all">Todos ({ads.length})</TabsTrigger>
                <TabsTrigger value="TOFU">TOFU ({ads.filter((ad) => ad.funnelStage === "TOFU").length})</TabsTrigger>
                <TabsTrigger value="MOFU">MOFU ({ads.filter((ad) => ad.funnelStage === "MOFU").length})</TabsTrigger>
                <TabsTrigger value="BOFU">BOFU ({ads.filter((ad) => ad.funnelStage === "BOFU").length})</TabsTrigger>
              </TabsList>
            </Tabs>

            {/* Ads Grid */}
            <div className="grid md:grid-cols-2 gap-6">
              {filteredAds.map((ad) => (
                <Card key={ad.id} className="card-gradient border-border/50 overflow-hidden">
                  <div className="aspect-video bg-muted/20 relative overflow-hidden">
                    <img
                      src={ad.imageUrl || "/placeholder.svg"}
                      alt={ad.title}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.target as HTMLImageElement
                        target.src = `/placeholder.svg?height=200&width=400&query=${encodeURIComponent(ad.title)}`
                      }}
                    />
                    <div className="absolute top-2 left-2 flex gap-2">
                      <Badge className={getPlatformColor(ad.platform)} variant="secondary">
                        {ad.platform === "meta" ? "Meta" : "Google"}
                      </Badge>
                      <div className="flex items-center gap-1">
                        <Badge className={getStageColor(ad.funnelStage)} variant="outline">
                          {ad.funnelStage}
                        </Badge>
                        {ad.confidence && ad.reasoning && (
                          <Tooltip>
                            <TooltipTrigger>
                              <InfoIcon />
                            </TooltipTrigger>
                            <TooltipContent className="max-w-xs">
                              <p className="text-xs">
                                <strong>Confiança:</strong> {Math.round(ad.confidence * 100)}%
                              </p>
                              <p className="text-xs mt-1">{ad.reasoning}</p>
                            </TooltipContent>
                          </Tooltip>
                        )}
                      </div>
                    </div>
                  </div>
                  <CardHeader>
                    <CardTitle className="text-lg line-clamp-2">{ad.title}</CardTitle>
                    <CardDescription className="line-clamp-3">{ad.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <CalendarIcon />
                        {new Date(ad.startDate).toLocaleDateString("pt-BR")}
                      </div>
                      <Badge variant="secondary">{ad.cta}</Badge>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                        <EyeIcon />
                        <span className="ml-2">Visualizar</span>
                      </Button>
                      <Button variant="outline" size="sm" asChild>
                        <a href={ad.landingPageUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLinkIcon />
                        </a>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Enhanced Insights Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-8 space-y-6">
              <Tabs defaultValue="insights" className="w-full">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="insights">Insights</TabsTrigger>
                  <TabsTrigger value="strategy">Estratégia</TabsTrigger>
                </TabsList>

                <TabsContent value="insights" className="space-y-6 mt-6">
                  <Card className="card-gradient border-border/50">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <TargetIcon />
                        Análise Automática
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      {/* Common Triggers */}
                      <div>
                        <h4 className="font-semibold mb-3">Gatilhos Mais Usados</h4>
                        <div className="flex flex-wrap gap-2">
                          {insights.commonTriggers.map((trigger, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {trigger}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      {/* Creative Suggestions */}
                      <div>
                        <h4 className="font-semibold mb-3">Sugestões de Criativos</h4>
                        <div className="space-y-3">
                          <div className="p-3 rounded-lg bg-chart-1/10 border border-chart-1/20">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge className={getStageColor("TOFU")} variant="outline" className="text-xs">
                                TOFU
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">{insights.creativesSuggestions.tofu}</p>
                          </div>
                          <div className="p-3 rounded-lg bg-chart-2/10 border border-chart-2/20">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge className={getStageColor("MOFU")} variant="outline" className="text-xs">
                                MOFU
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">{insights.creativesSuggestions.mofu}</p>
                          </div>
                          <div className="p-3 rounded-lg bg-chart-3/10 border border-chart-3/20">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge className={getStageColor("BOFU")} variant="outline" className="text-xs">
                                BOFU
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">{insights.creativesSuggestions.bofu}</p>
                          </div>
                        </div>
                      </div>

                      {/* Landing Page Structure */}
                      <div>
                        <h4 className="font-semibold mb-3">Estrutura de Landing Page</h4>
                        <ul className="space-y-2">
                          {insights.landingPageStructure.map((item, index) => (
                            <li key={index} className="text-sm text-muted-foreground flex items-start gap-2">
                              <span className="w-1.5 h-1.5 rounded-full bg-primary mt-2 flex-shrink-0" />
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="strategy" className="space-y-6 mt-6">
                  {/* Competitive Analysis */}
                  {insights.competitiveAnalysis && (
                    <Card className="card-gradient border-border/50">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <TrendingUpIcon />
                          Análise Competitiva
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-2 text-sm">Pontos Fortes dos Concorrentes</h4>
                          <ul className="space-y-1">
                            {insights.competitiveAnalysis.strengths.map((strength, index) => (
                              <li key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                                <CheckCircleIcon />
                                {strength}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2 text-sm">Oportunidades</h4>
                          <ul className="space-y-1">
                            {insights.competitiveAnalysis.opportunities.map((opportunity, index) => (
                              <li key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                                <LightbulbIcon />
                                {opportunity}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2 text-sm">Tendências do Mercado</h4>
                          <ul className="space-y-1">
                            {insights.competitiveAnalysis.trends.map((trend, index) => (
                              <li key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                                <TrendingUpIcon />
                                {trend}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Recommendations */}
                  {insights.recommendations && (
                    <Card className="card-gradient border-border/50">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                          <LightbulbIcon />
                          Recomendações
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-2 text-sm">Ações Imediatas</h4>
                          <ul className="space-y-1">
                            {insights.recommendations.immediate.map((action, index) => (
                              <li key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-orange-500 mt-2 flex-shrink-0" />
                                {action}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2 text-sm">Estratégias de Longo Prazo</h4>
                          <ul className="space-y-1">
                            {insights.recommendations.longTerm.map((strategy, index) => (
                              <li key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                                <span className="w-1.5 h-1.5 rounded-full bg-purple-500 mt-2 flex-shrink-0" />
                                {strategy}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </div>
    </TooltipProvider>
  )
}
